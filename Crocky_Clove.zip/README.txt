Make sure Roblox is open

Fixes:
ESP/Aimbot not working/Invalid Roblox Version:
Install Fishtrap and make sure you're on production build in Deployment Tab
Auth Issue:
Go to the Clock on your PC
Right-click the clock (bottom-right of your screen)
Click Adjust date and time
Turn ON:
Set time automatically
Set time zone automatically
Click Sync now
Restart the app/program and try again